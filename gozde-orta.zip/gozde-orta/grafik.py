import pandas as pd 
import matplotlib.pyplot as plt

df=pd.read_excel(r'C:\Users\Pc\Desktop\yaz-staji\dakikalar.xlsx')
puan=df['PUAN']
puanlar=df.groupby('PUAN').size()
print(puanlar)
plt.figure(figsize=(8, 6))
sutunlar=puanlar.plot.bar(color='green')
for sutun in sutunlar.patches:
    yval = sutun.get_height()
    plt.text(sutun.get_x() + sutun.get_width() / 2, yval + 0.1, int(yval), ha='center', va='bottom', fontsize=12, color='black')
plt.title('Makine Puanları',fontsize=16)
plt.xlabel('Puanlar',fontsize=12)
plt.ylabel('Makine Sayısı',fontsize=12)

plt.show()