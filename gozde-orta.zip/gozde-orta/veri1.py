import numpy as np
import pandas as pd

df = pd.read_excel(r'C:\Users\Pc\Desktop\yaz-staji\makine-zaman-bazli-özet-rapor.xlsx', sheet_name='Sheet1')


def dakika(zaman):
    if isinstance(zaman, str):
        try:
           
            times = np.array(list(map(int, zaman.split(':'))))
            saat, dakika, saniye = times
            
            toplam_dakika = saat* 60 + dakika + saniye / 60
            return toplam_dakika
        except (ValueError, TypeError):
           
            return np.nan  
    return zaman


for sutun in df.columns[2:9]:  
    print(f"İşleniyor: {sutun}")
    df[sutun] = df[sutun].astype(str)  
    df[sutun] = df[sutun].apply(dakika)


df.to_excel('dakikalar.xlsx', index=False)

print("İşlem tamamlandı.")
print(df)


