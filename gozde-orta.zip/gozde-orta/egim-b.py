
import cv2
from roboflow import Roboflow
import pyrealsense2 as rs 
import numpy as np
from sklearn.decomposition import PCA



rf = Roboflow(api_key="BnK6h4TH8DYIKIBQJGdc")
project = rf.workspace().project("phone-segmentation-2")
model = project.version(1).model
pipe=rs.pipeline()
cfg=rs.config()
cfg.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

pipe.start(cfg)
blended=None

try:
    while True:
        frames=pipe.wait_for_frames()
        color_frame=frames.get_color_frame()
        if not color_frame:
            continue
        color_image=np.asanyarray(color_frame.get_data())
        temp_image_path='temp.jpg'
        cv2.imwrite(temp_image_path,color_image)

        predictions=model.predict(temp_image_path, confidence=80).json()

        mask=np.zeros(color_image.shape[:2], dtype=np.uint8)
        

        for prediction in predictions['predictions']:
            if 'points' in prediction:
                points=prediction['points']
                points=np.array([[point['x'], point['y']] for point in points],dtype=np.int32)
    
                x1 = int(prediction['x'] - prediction['width'] / 2)
                y1 = int(prediction['y'] - prediction['height'] / 2)
                x2 = int(prediction['x'] + prediction['width'] / 2)
                y2 = int(prediction['y'] + prediction['height'] / 2)

                dot_x=(x1+x2)/2
                dot_y=(y1+y2)/2
                
                box_center=((int(dot_x)),(int(dot_y)))

               

                cv2.circle(color_image, box_center, 3, (0,255,255), -1 )

                label = prediction['class'] 
                confidence=prediction.get('confidence',0)*100
                cv2.fillPoly(mask, [points], color=255)
                cv2.rectangle(color_image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(color_image, f"Telefon-{confidence:.2f}%", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            if points.size!=0:
                pca=PCA(n_components=2)
                pca.fit(points)  

                center=np.mean(points, axis=0)
                principal_component=pca.components_[0]

                angle=np.arctan2(principal_component[1], principal_component[0])
                angle_degrees=np.degrees(angle)

               

                point1=box_center-principal_component*100
                point2=box_center+principal_component*100
               
                cv2.arrowedLine(color_image, tuple(point1.astype(int)), tuple(point2.astype(int)), (255,255,255), 2)
       
                cv2.putText(color_image, f'{angle_degrees:.2f}' , (x2, y2 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
                print(f"Eğim: {angle_degrees:.2f} derece")
        result=cv2.bitwise_and(color_image,color_image,mask=mask)
        color_mask=np.zeros_like(color_image)
        color_mask[mask==255]=[0,255,0]
        blended=cv2.addWeighted(color_image,0.7,color_mask,0.3,0)
        cv2.imshow('camera',color_image)
       
        if blended is not None:
            cv2.imwrite('sonuc.jpg',blended)
            cv2.imshow('camera',blended)
        if cv2.waitKey(1) & 0xFF==ord('q'):
            break
finally:       
    pipe.stop()
    cv2.destroyAllWindows()