import pandas as pd

df=pd.read_excel('C:/Users/Pc/Desktop/makine-listesi.xlsx', sheet_name='Sheet')


df_kod_grouped=df.groupby('IP')['KODU'].apply(lambda x: '-'.join(x)).reset_index()
df_grup_grouped=df.groupby('IP')[['GRUP1']].first().reset_index()

df_final = pd.merge(df_kod_grouped, df_grup_grouped, on='IP')

df_final.to_excel('makine.xlsx', index=False)

print('basarılı')