import pyrealsense2 as rs
import cv2 
import numpy as np


pipe=rs.pipeline()
cfg=rs.config()
#kameradan anlık 
cfg.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
cfg.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
profile=pipe.start(cfg)

point=(200,300)


try:
    while True:
        frames=pipe.wait_for_frames()
        depth_frame=frames.get_depth_frame()
        color_frame=frames.get_color_frame()
       
        if not depth_frame or not color_frame:
            continue
        
        depth_color_frame=rs.colorizer().colorize(depth_frame)
        depth_image=np.asanyarray(depth_color_frame.get_data())


        color_image=np.asanyarray(color_frame.get_data())

        depth_image_8bit=cv2.normalize(depth_image, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)

        depth_scale = profile.get_device().first_depth_sensor().get_depth_scale()
        distance=depth_frame.get_distance(point[0], point[1])

     
        cv2.circle(color_image, point, 5, (255,255,255), -1)
        print(distance)


        cv2.imshow("depth image", depth_image_8bit)
        cv2.imshow("color image", color_image)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
        pipe.stop()
        cv2.destroyAllWindows()

