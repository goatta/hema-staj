import pandas as pd
import numpy as np

df=pd.read_excel(r'C:\Users\Pc\Desktop\yaz-staji\dakikalar.xlsx')

start=df['START']
toplam=df['TOPLAM']
reset=df['RESET']
yuzde=round(((reset+start)/toplam)*100,2)
df['Calisma(%)']=yuzde

def puan_hesap(yuzde):
    #if isinstance(yuzde,str):
        
        if yuzde >= 80:
            return 1
        elif yuzde<80 and yuzde >=50:
            return 2
        elif yuzde==0:
            return 0
        elif yuzde<50:
            return 3
        
puan=yuzde.apply(puan_hesap)
df['PUAN']=puan
print(puan, yuzde)

df.to_excel(r'C:\Users\Pc\Desktop\yaz-staji\dakikalar.xlsx')
