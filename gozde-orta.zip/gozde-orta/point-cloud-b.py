import open3d as o3d
import numpy as np
import cv2
import pyrealsense2 as rs


pipe=rs.pipeline()

cfg=rs.config()
cfg.enable_stream(rs.stream.depth, 640,480, rs.format.z16,30)
cfg.enable_stream(rs.stream.color, 640,480, rs.format.rgb8,30)
pipe.start(cfg)




try:
    while True:
        frames=pipe.wait_for_frames()
        depth_frame=frames.get_depth_frame()
        color_frame=frames.get_color_frame()

        if not depth_frame or not color_frame:
            continue

        depth_colorize=rs.colorizer().colorize(depth_frame)
        depth_image=np.asanyarray(depth_colorize.get_data())
        color_image=np.asanyarray(color_frame.get_data())
        cv2.imshow('Color',color_image)
        cv2.imshow('Depth',depth_image)

        profile=pipe.get_active_profile()
        intr=profile.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()

        pinhole_camera_intrinsic=o3d.camera.PinholeCameraIntrinsic(
            intr.width, intr.height, intr.fx, intr.fy, intr.ppx, intr.ppy
        )

        depth_o3d=o3d.geometry.Image(depth_image)
        color_o3d=o3d.geometry.Image(color_image)

        rgbd_image=o3d.geometry.RGBDImage.create_from_color_and_depth(
            color_o3d,
            depth_o3d,
            depth_scale=1000.0,
            depth_trunc=3000.0,
            convert_rgb_to_intensity=False
        )
        #pcd.clear()
        temp_pcd=o3d.geometry.PointCloud.create_from_rgbd_image(
            rgbd_image,
            pinhole_camera_intrinsic
        )
        #pcd=o3d.t.geometry.PointCloud()

        print(temp_pcd)
        #pcd.points=temp_pcd.points
        print(np.asanyarray(temp_pcd.points))
        #pcd.colors=temp_pcd.colors
        #read_pcd=o3d.io.read_point_cloud(np.asanyarray(temp_pcd.points))
        #print(read_pcd)
        #vis.update_geometry(pcd)
        # vis.poll_events()
        # vis.update_renderer()
        #print(rgbd_image)

        temp_pcd.transform([[1,0,0,0],
                         [0,-1,0,0],
                         [0,0,-1,0],
                         [0,0,0,1]])
        # def close_window(vis):
        #     vis.close()
        #     return False
        # key_to_callback={ord('q'): close_window}
        o3d.visualization.draw_geometries([temp_pcd]
                            #   zoom=0.3412,
                            #   front=[0.4257, -0.2125, -0.8795],
                            #   lookat=[2.6172, 2.0475, 1.532],
                            #   up=[-0.0694, -0.9768, 0.2024]
                            )
        if cv2.waitKey(0) & 0xFF==ord('q'):
            break
finally:
    pipe.stop()
    #vis.destroy_window()
    cv2.destroyAllWindows()