import cv2
import pyrealsense2 as rs
import open3d as o3d
import numpy as np
from roboflow import Roboflow
import torch
#modeli roboflow api kullanarak içe aktarma
rf = Roboflow(api_key="BnK6h4TH8DYIKIBQJGdc")
project = rf.workspace().project("phone-segmentation-2")
model = project.version(1).model
#kameradan görüntü almak için pipeline başlatma

pipe=rs.pipeline()
cfg=rs.config()
cfg.enable_stream(rs.stream.depth, 640,480, rs.format.z16,30)
cfg.enable_stream(rs.stream.color, 640,480, rs.format.bgr8,30)


start=pipe.start(cfg)


def segmentasyon(color_image,depth_frame,mask):
            global result,blended
            for prediction in predictions['predictions']:
                if 'points' in prediction:
                    points=prediction['points']
                    points=np.array([[point['x'], point['y']] for point in points],dtype=np.int32)
                    
                    x1 = int(prediction['x'] - prediction['width'] / 2)
                    y1 = int(prediction['y'] - prediction['height'] / 2)
                    x2 = int(prediction['x'] + prediction['width'] / 2)
                    y2 = int(prediction['y'] + prediction['height'] / 2)
                
                    confidence=prediction.get('confidence',0)*100
                    
                    dot_x=(x1+x2)/2
                    dot_y=(y1+y2)/2
                    box_center=((int(dot_x)),(int(dot_y)))
                    
                    cv2.circle(color_image, box_center, 3, (0,255,0),-1)
                    cv2.fillPoly(mask, [points], color=255)
                    cv2.rectangle(color_image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(color_image, f"Telefon-{confidence:.2f}%", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                   
                
            result=cv2.bitwise_and(color_image,color_image,mask=mask)
           
            color_mask=np.zeros_like(color_image)
            color_mask[mask==255]=[0,255,0]
            blended=cv2.addWeighted(color_image,0.7,color_mask,0.3,0)
            #model tarafından bulunan nesnenin maskesi ve doğruluk oranı yazar
            
                            
                           
            cv2.imshow('camera',blended)
            cv2.imshow('depth',depth_image)
            
            cv2.imwrite(temp_image_path,blended)
                           
                      
            return mask
def point_cloud(depth_value,color_image,mask_255,pipe):    
                           
                       #kmaeradan alınan derinlik ve renk verileri ile nesnenin nokta bulutunu oluşturur  
                       
                        profile=pipe.get_active_profile()
                
                        intr=profile.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
                        pinhole_camera_intrinsic=o3d.camera.PinholeCameraIntrinsic(
                        intr.width, intr.height, intr.fx, intr.fy, intr.ppx, intr.ppy
                     )
           

                        masked_depth = depth_value*(mask.astype(np.bool_))
                        
                        masked_image_contiguous = np.ascontiguousarray(color_image[mask_255].astype(np.uint16))
                        phone_depth_o3d=o3d.geometry.Image(masked_depth.astype(np.uint16))
                        phone_color_o3d=o3d.geometry.Image(result)

                        rgbd_image=o3d.geometry.RGBDImage.create_from_color_and_depth(
                        phone_color_o3d,
                        phone_depth_o3d,
                        depth_scale=1000.0,
                        depth_trunc=3.0,
                        convert_rgb_to_intensity=True
                        )
                        temp_pcd=o3d.geometry.PointCloud.create_from_rgbd_image(
                        rgbd_image,
                        pinhole_camera_intrinsic
                        )
                        temp_pcd.transform([[1,0,0,0],
                                 [0,-1,0,0],
                                 [0,0,-1,0],
                                 [0,0,0,1]])
                       

                        print(temp_pcd)
                        return temp_pcd
                        
try:
    while True:
            
            frames=pipe.wait_for_frames()
            color_frame=frames.get_color_frame()
            depth_frame=frames.get_depth_frame()
            temp_image_path='temp.jpg'
            if not depth_frame or not color_frame:
                continue
            #kameradan derinlik ve bgr görüntü alma
            depth_colorize=rs.colorizer().colorize(depth_frame)
            depth_value=np.asanyarray(depth_frame.get_data(),dtype=np.uint16)
            color_image=np.asanyarray(color_frame.get_data())
            depth_image=np.asanyarray(depth_colorize.get_data())
            #modelin %80 doğruluk oranı ile nesne araması sağlanır 
            predictions=model.predict(temp_image_path, confidence=80).json()
            mask=np.zeros(color_image.shape[:2], dtype=np.uint8)
            mask=segmentasyon(color_image,depth_frame,mask)
           
           
           
            if mask.any() :
            #maskede herhangi bir sonuç varsa yani nesne algılandıysa point cloud çizer
                t_pcd=point_cloud(depth_value,color_image,mask,pipe)
                print(np.asanyarray(t_pcd.points))
                if t_pcd.has_points():
                        
                    o3d.visualization.draw_geometries([t_pcd])
                break
            else:
                    print('nesne bulunamadi')
            
            if cv2.waitKey(1) & 0xFF==ord('q'):
                    break
finally: 
     pipe.stop()
     cv2.destroyAllWindows()