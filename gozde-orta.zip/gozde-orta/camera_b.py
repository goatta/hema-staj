import pyrealsense2 as rs
import cv2
import numpy as np

pipe=rs.pipeline()
cfg=rs.config()
cfg.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
cfg.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

def camera():
        pipe.start(cfg)
        try:
            while True:
              
                frames=pipe.wait_for_frames()
                color_frame=frames.get_color_frame()
                depth_frame=frames.get_depth_frame()
                if not color_frame or not depth_frame:
                    continue


                color_image=np.asanyarray(color_frame.get_data())
                depth_colorize=rs.colorizer().colorize(depth_frame)
                depth_image=np.asanyarray(depth_colorize.get_data())



                cv2.imshow('goruntu',color_image)
                cv2.imshow('derinlik',depth_image)






                if cv2.waitKey(1)&0xFF==ord('q'):
                    break





                #saved_image='saved.jpg'
                #cv2.imwrite(saved_image,color_image) #nokta bulutunu kaydet 

        
        finally:
            pipe.stop()
            cv2.destroyAllWindows()
        return depth_image, color_image, depth_frame
camera()